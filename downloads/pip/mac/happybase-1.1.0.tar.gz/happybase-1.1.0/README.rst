HappyBase
=========

**HappyBase** is a developer-friendly Python_ library to interact with Apache
HBase_.

* `Documentation <https://happybase.readthedocs.io/>`_ (Read the Docs)
* `Downloads <http://pypi.python.org/pypi/happybase/>`_ (PyPI)
* `Source code <https://github.com/wbolster/happybase>`_ (Github)

.. _Python: http://python.org/
.. _HBase: http://hbase.apache.org/

.. If you're reading this from the README.rst file in a source tree,
   you can generate the HTML documentation by running "make doc" and browsing
   to doc/build/html/index.html to see the result.


.. image:: https://d2weczhvl823v0.cloudfront.net/wbolster/happybase/trend.png
   :alt: Bitdeli badge
   :target: https://bitdeli.com/free
